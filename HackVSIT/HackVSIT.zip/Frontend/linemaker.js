createLine('point1', 'point2', 'line12');
createLine('point2', 'point3', 'line23');
createLine('point3', 'point4', 'line34');
createLine('point4', 'point5', 'line45');
createLine('point5', 'point6', 'line56');
createLine('point5', 'point55', 'line555');
createLine('point1', 'point11', 'line111');
createLine('point2', 'point21', 'line221');
createLine('point3', 'point31', 'line331');
createLine('point4', 'point41', 'line441');
createLine('point5', 'point51', 'line551');
createLine('point6', 'point61', 'line661');

createLine('point11', 'point12', 'line1112');
createLine('point21', 'point22', 'line2122');
createLine('point31', 'point32', 'line3132');
createLine('point41', 'point42', 'line4142');
createLine('point51', 'point52', 'line5152');
createLine('point61', 'point62', 'line6162');

createLine('point12', 'point13', 'line1213');
createLine('point22', 'point23', 'line2223');
createLine('point32', 'point33', 'line3233');
createLine('point42', 'point43', 'line4243');
createLine('point52', 'point53', 'line5253');
createLine('point62', 'point63', 'line6263');

createLine('point13', 'point14', 'line1314');
createLine('point23', 'point24', 'line2324');
createLine('point33', 'point34', 'line3334');
createLine('point43', 'point44', 'line4344');
createLine('point53', 'point54', 'line5354');
createLine('point63', 'point64', 'line6364');

createLine('point14', 'point15', 'line1415');
createLine('point24', 'point25', 'line2425');
createLine('point34', 'point35', 'line3435');
createLine('point44', 'point45', 'line4445');
createLine('point54', 'point55', 'line5455');
createLine('point64', 'point65', 'line6465');

/*Creating the other horizontal line*/

createLine('point11', 'point21', 'line1121');
createLine('point21', 'point31', 'line2131');
createLine('point31', 'point41', 'line3141');
createLine('point41', 'point51', 'line4151');
createLine('point51', 'point61', 'line5161');

createLine('point12', 'point22', 'line1222');
createLine('point22', 'point32', 'line2232');
createLine('point32', 'point42', 'line3242');
createLine('point42', 'point52', 'line4252');
createLine('point52', 'point62', 'line5262');

createLine('point13', 'point23', 'line1323');
createLine('point23', 'point33', 'line2333');
createLine('point33', 'point43', 'line3343');
createLine('point43', 'point53', 'line4353');
createLine('point53', 'point63', 'line5363');

createLine('point14', 'point24', 'line1424');
createLine('point24', 'point34', 'line2434');
createLine('point34', 'point44', 'line3444');
createLine('point44', 'point54', 'line4454');
createLine('point54', 'point64', 'line5464');

createLine('point15', 'point25', 'line1525');
createLine('point25', 'point35', 'line2535');
createLine('point35', 'point45', 'line3545');
createLine('point45', 'point55', 'line4555');
createLine('point55', 'point65', 'line5565');
